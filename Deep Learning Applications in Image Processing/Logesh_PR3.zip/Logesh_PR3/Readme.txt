PR-3

You can see the program stored in Part_A,Part_B,Part_C. Both python and jupyter files are available in each
folder seperately.

Input Images: You can see my 7 input images in Part_C folder.

Output Images: You can see the output segmentation images and feature maps in Part_C folder stored 
in seperate folders. You can also open the Part_C.ipynb folder and view the outputs.