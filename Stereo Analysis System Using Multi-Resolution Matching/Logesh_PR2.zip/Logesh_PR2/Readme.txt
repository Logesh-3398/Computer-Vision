PR2:

Run using Google collab


Input images: Load input images from the file which is given by me as input images. 
while running the code, user should define the image name as mentioned in code.
example: sawtooth,venus,bull,poster and barn1.


Other inputs: User should define number of levels,method,search region, width and height of template window.

Output images: output images are saved for your convenience as output images on different file names. 
but if you run the code you can the output images as disparity_level_1.png and so on based on levels.
